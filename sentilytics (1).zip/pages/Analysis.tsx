import React, { useContext } from 'react';
import { DataContext } from '../App';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from 'recharts';
import Card from '../components/ui/Card';
import { Loader } from 'lucide-react';

const COLORS = ['#10B981', '#F59E0B', '#EF4444']; // Green, Yellow, Red

const Analysis: React.FC = () => {
  const { nlpResults, loading } = useContext(DataContext)!;

  if (loading) {
    return (
      <div className="min-h-[60vh] flex flex-col items-center justify-center text-slate-500">
        <Loader className="animate-spin h-12 w-12 text-indigo-600 mb-4" />
        <p className="text-lg font-medium">Analyzing Sentiment with Gemini AI...</p>
        <p className="text-sm">This may take a moment.</p>
      </div>
    );
  }

  if (!nlpResults) {
    return (
      <div className="text-center py-20">
        <h2 className="text-2xl font-bold text-slate-700">No Analysis Available</h2>
        <p className="text-slate-500 mt-2">Go to Dashboard and run analysis on a dataset first.</p>
      </div>
    );
  }

  const chartData = [
    { name: 'Positive', value: nlpResults.stats.positive },
    { name: 'Neutral', value: nlpResults.stats.neutral },
    { name: 'Negative', value: nlpResults.stats.negative },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <h1 className="text-3xl font-bold text-slate-900 mb-6">NLP Performance & Sentiment</h1>

      {/* Summary Section */}
      <Card title="Executive Summary" className="mb-6 bg-gradient-to-r from-slate-900 to-slate-800 text-white">
        <p className="text-slate-200 leading-relaxed text-lg">
          {nlpResults.summary}
        </p>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        {/* Pie Chart */}
        <Card title="Sentiment Distribution" className="h-96">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={chartData}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={100}
                fill="#8884d8"
                paddingAngle={5}
                dataKey="value"
              >
                {chartData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
              <Legend verticalAlign="bottom" height={36}/>
            </PieChart>
          </ResponsiveContainer>
        </Card>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 gap-4">
           <Card className="flex items-center justify-between border-l-4 border-l-green-500">
              <div>
                <p className="text-sm text-slate-500 font-medium">Positive</p>
                <h3 className="text-2xl font-bold text-slate-800">{nlpResults.stats.positive}</h3>
              </div>
              <div className="h-10 w-10 rounded-full bg-green-100 flex items-center justify-center text-green-600">
                <span className="text-xl">😊</span>
              </div>
           </Card>
           <Card className="flex items-center justify-between border-l-4 border-l-yellow-500">
              <div>
                <p className="text-sm text-slate-500 font-medium">Neutral</p>
                <h3 className="text-2xl font-bold text-slate-800">{nlpResults.stats.neutral}</h3>
              </div>
              <div className="h-10 w-10 rounded-full bg-yellow-100 flex items-center justify-center text-yellow-600">
                <span className="text-xl">😐</span>
              </div>
           </Card>
           <Card className="flex items-center justify-between border-l-4 border-l-red-500">
              <div>
                <p className="text-sm text-slate-500 font-medium">Negative</p>
                <h3 className="text-2xl font-bold text-slate-800">{nlpResults.stats.negative}</h3>
              </div>
              <div className="h-10 w-10 rounded-full bg-red-100 flex items-center justify-center text-red-600">
                <span className="text-xl">😠</span>
              </div>
           </Card>
        </div>
      </div>

      {/* Word Cloud Visual */}
      <Card title="Word Cloud Analysis" className="mb-8">
        <div className="flex flex-wrap gap-3 justify-center p-4">
          {nlpResults.wordCloud.map((item, idx) => {
             // Calculate size relative to max value for simple word cloud logic
             const sizeClass = item.value > 20 ? 'text-4xl' : item.value > 10 ? 'text-2xl' : 'text-sm';
             const colorClass = item.sentiment === 'positive' ? 'text-green-600' : item.sentiment === 'negative' ? 'text-red-500' : 'text-slate-400';
             
             return (
               <span 
                key={idx} 
                className={`${sizeClass} ${colorClass} font-bold cursor-default hover:scale-110 transition-transform`}
                title={`Count: ${item.value}`}
               >
                 {item.text}
               </span>
             )
          })}
        </div>
      </Card>
    </div>
  );
};

export default Analysis;