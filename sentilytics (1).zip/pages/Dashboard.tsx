import React, { useContext, useEffect } from 'react';
import { DataContext } from '../App';
import Card from '../components/ui/Card';
import { Database, Clock, FileText, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

const Dashboard: React.FC = () => {
  const { datasets, loadDashboardData, runAnalysis } = useContext(DataContext)!;

  useEffect(() => {
    loadDashboardData();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleAnalyze = async (id: string) => {
    await runAnalysis(id);
    window.location.hash = '#/analysis';
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-slate-900">Dashboard</h1>
        <p className="text-slate-500 mt-2">Manage your datasets and view recent activity.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card className="bg-gradient-to-br from-indigo-500 to-indigo-600 text-white border-none">
          <div className="flex items-center space-x-4">
            <div className="p-3 bg-white/20 rounded-lg">
              <Database size={24} />
            </div>
            <div>
              <p className="text-indigo-100 text-sm font-medium">Total Datasets</p>
              <p className="text-2xl font-bold">{datasets.length}</p>
            </div>
          </div>
        </Card>
         <Card className="bg-white">
          <div className="flex items-center space-x-4">
            <div className="p-3 bg-green-100 text-green-600 rounded-lg">
              <Clock size={24} />
            </div>
            <div>
              <p className="text-slate-500 text-sm font-medium">Last Upload</p>
              <p className="text-lg font-bold text-slate-800">
                {datasets.length > 0 ? new Date(datasets[datasets.length - 1].uploadDate).toLocaleDateString() : 'N/A'}
              </p>
            </div>
          </div>
        </Card>
      </div>

      <h2 className="text-xl font-bold text-slate-900 mb-4">Your Datasets</h2>
      {datasets.length === 0 ? (
        <div className="text-center py-12 bg-white rounded-xl border border-dashed border-slate-300">
          <FileText className="mx-auto h-12 w-12 text-slate-300" />
          <h3 className="mt-2 text-sm font-medium text-slate-900">No datasets</h3>
          <p className="mt-1 text-sm text-slate-500">Get started by uploading a new dataset.</p>
          <div className="mt-6">
            <Link to="/upload" className="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700">
              Upload Dataset
            </Link>
          </div>
        </div>
      ) : (
        <div className="grid gap-6">
          {datasets.map((d) => (
            <Card key={d.id} className="flex flex-col md:flex-row md:items-center justify-between">
              <div className="flex-1">
                <div className="flex items-center space-x-3 mb-2">
                  <FileText className="text-indigo-500" />
                  <h3 className="text-lg font-semibold text-slate-900">{d.name}</h3>
                  <span className="px-2 py-1 bg-slate-100 text-xs font-medium text-slate-600 rounded-full">
                    {d.rowCount} rows
                  </span>
                </div>
                <p className="text-sm text-slate-500">Uploaded on {new Date(d.uploadDate).toLocaleString()}</p>
              </div>
              <div className="mt-4 md:mt-0 flex space-x-3">
                 <button 
                  onClick={() => handleAnalyze(d.id)}
                  className="flex items-center space-x-1 text-sm font-medium text-indigo-600 hover:text-indigo-800 bg-indigo-50 hover:bg-indigo-100 px-4 py-2 rounded-lg transition-colors"
                >
                  <span>Run Analysis</span>
                  <ArrowRight size={16} />
                </button>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};

export default Dashboard;