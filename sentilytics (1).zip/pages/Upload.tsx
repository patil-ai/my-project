import React, { useContext, useState } from 'react';
import { DataContext } from '../App';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import { UploadCloud, FileText, CheckCircle, AlertCircle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const Upload: React.FC = () => {
  const { uploadDataset, loading } = useContext(DataContext)!;
  const navigate = useNavigate();
  const [file, setFile] = useState<File | null>(null);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const selected = e.target.files[0];
      if (selected.type !== 'text/csv' && !selected.name.endsWith('.csv')) {
        setError('Please upload a valid CSV file.');
        setFile(null);
        return;
      }
      setFile(selected);
      setError('');
      setSuccess(false);
    }
  };

  const handleUpload = async () => {
    if (!file) return;
    try {
      await uploadDataset(file);
      setSuccess(true);
      setTimeout(() => navigate('/dashboard'), 1500);
    } catch (e) {
      setError('Failed to upload file.');
    }
  };

  return (
    <div className="max-w-3xl mx-auto px-4 py-12">
      <div className="mb-8 text-center">
        <h1 className="text-3xl font-bold text-slate-900">Upload Dataset</h1>
        <p className="text-slate-500 mt-2">Upload your CSV file for sentiment analysis. Ensure it has a text column.</p>
      </div>

      <Card className="p-10">
        <div className="border-2 border-dashed border-slate-300 rounded-lg p-12 text-center hover:border-indigo-500 transition-colors bg-slate-50">
          <input
            type="file"
            id="file-upload"
            className="hidden"
            accept=".csv"
            onChange={handleFileChange}
          />
          
          <label htmlFor="file-upload" className="cursor-pointer flex flex-col items-center">
             {file ? (
               <div className="bg-indigo-100 p-4 rounded-full text-indigo-600 mb-4">
                 <FileText size={40} />
               </div>
             ) : (
               <div className="bg-slate-200 p-4 rounded-full text-slate-500 mb-4">
                 <UploadCloud size={40} />
               </div>
             )}
            
            <span className="text-lg font-medium text-slate-900 block mb-1">
              {file ? file.name : "Click to upload CSV"}
            </span>
            <span className="text-sm text-slate-500">
              {file ? `${(file.size / 1024).toFixed(2)} KB` : "Max file size: 5MB"}
            </span>
          </label>
        </div>

        {error && (
          <div className="mt-4 p-3 bg-red-50 text-red-600 rounded-lg flex items-center text-sm">
            <AlertCircle size={16} className="mr-2" />
            {error}
          </div>
        )}

        {success && (
          <div className="mt-4 p-3 bg-green-50 text-green-600 rounded-lg flex items-center text-sm">
            <CheckCircle size={16} className="mr-2" />
            Dataset uploaded successfully! Redirecting...
          </div>
        )}

        <div className="mt-8 flex justify-end">
          <Button 
            disabled={!file} 
            isLoading={loading}
            onClick={handleUpload}
            className="w-full sm:w-auto"
          >
            Process Dataset
          </Button>
        </div>
      </Card>
    </div>
  );
};

export default Upload;