
import { GoogleGenAI, Type } from "@google/genai";
import { NLPResults, ModelMetric } from '../types';

export class GeminiService {
  private ai: GoogleGenAI;

  constructor() {
    this.ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
  }

  async analyzeSentiment(textData: string): Promise<Omit<NLPResults, 'datasetId'>> {
    // Slice to ensure we stay within reasonable context window for the demo
    const sampleData = textData.slice(0, 30000); 

    const prompt = `
      Perform advanced Sentiment Analysis on the following text data (extracted from a specific dataset column).
      
      Tasks:
      1. Calculate sentiment statistics (positive, negative, neutral counts).
      2. Write a concise executive summary of the prevailing sentiment and key topics.
      3. Generate keywords for Word Clouds. **CRITICAL**: You must identify distinct words for each sentiment category.
         - Find top 20 distinct POSITIVE words.
         - Find top 20 distinct NEGATIVE words.
         - Find top 15 distinct NEUTRAL/Topical words.
         - Exclude common stop words (e.g., 'the', 'and', 'is', 'it').
      
      Return JSON:
    `;

    try {
      const response = await this.ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt + "\n\nTEXT DATA SAMPLE:\n" + sampleData,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              stats: {
                type: Type.OBJECT,
                properties: {
                  positive: { type: Type.NUMBER },
                  negative: { type: Type.NUMBER },
                  neutral: { type: Type.NUMBER },
                  total: { type: Type.NUMBER },
                }
              },
              summary: { type: Type.STRING },
              wordCloud: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    text: { type: Type.STRING },
                    value: { type: Type.NUMBER },
                    sentiment: { type: Type.STRING, enum: ['positive', 'negative', 'neutral'] }
                  }
                }
              }
            }
          }
        }
      });

      if (response.text) {
        return JSON.parse(response.text);
      }
      throw new Error("No response text");
    } catch (error) {
      console.error("Gemini Analysis Error:", error);
      throw error;
    }
  }

  async generateMLMetrics(textData: string): Promise<ModelMetric[]> {
    const sampleData = textData.slice(0, 30000);

    const prompt = `
      Act as a Lead Machine Learning Engineer.
      Based on the provided text samples, SIMULATE the training and evaluation of two sentiment classification models:
      1. Logistic Regression
      2. Decision Tree

      Analyze the complexity and separability of the text to estimate realistic performance metrics.
      
      Return JSON array with:
      - accuracy, precision, recall, f1Score (all 0.0 - 1.0)
      - confusionMatrix: { tp, tn, fp, fn } (based on n=1000 test set)
    `;

    try {
      const response = await this.ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt + "\n\nTEXT DATA SAMPLE:\n" + sampleData,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                modelName: { type: Type.STRING },
                accuracy: { type: Type.NUMBER },
                precision: { type: Type.NUMBER },
                recall: { type: Type.NUMBER },
                f1Score: { type: Type.NUMBER },
                confusionMatrix: {
                  type: Type.OBJECT,
                  properties: {
                    tp: { type: Type.NUMBER },
                    tn: { type: Type.NUMBER },
                    fp: { type: Type.NUMBER },
                    fn: { type: Type.NUMBER },
                  }
                }
              }
            }
          }
        }
      });

      if (response.text) {
        return JSON.parse(response.text);
      }
      throw new Error("No metrics generated");
    } catch (error) {
      console.error("Gemini ML Metrics Error:", error);
      throw error;
    }
  }
}
