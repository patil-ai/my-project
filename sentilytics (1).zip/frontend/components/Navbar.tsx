import React, { useContext, useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { AuthContext } from '../App';
import { Menu, X, BrainCircuit, LayoutDashboard, UploadCloud, PieChart, Activity, LogOut, LogIn } from 'lucide-react';

const Navbar: React.FC = () => {
  const { isAuthenticated, user, logout } = useContext(AuthContext)!;
  const [isOpen, setIsOpen] = useState(false);
  const location = useLocation();

  // Active state now uses a solid indigo background for clear visual distinction
  const isActive = (path: string) => location.pathname === path 
    ? 'bg-indigo-600 text-white shadow-md' 
    : 'text-slate-300 hover:bg-slate-800 hover:text-white';

  const NavItem = ({ to, icon: Icon, label }: any) => (
    <Link
      to={to}
      onClick={() => setIsOpen(false)}
      className={`flex items-center space-x-2 px-3 py-2 rounded-md text-sm font-medium transition-all duration-200 ${isActive(to)}`}
    >
      <Icon size={18} />
      <span>{label}</span>
    </Link>
  );

  return (
    <nav className="bg-slate-900 border-b border-slate-800 sticky top-0 z-50 shadow-lg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <Link to="/" className="flex items-center space-x-2">
              <div className="bg-white/10 p-2 rounded-lg backdrop-blur-sm border border-white/5">
                <BrainCircuit className="text-indigo-400 h-6 w-6" />
              </div>
              <span className="text-xl font-bold text-white tracking-wide">
                Sentilytics
              </span>
            </Link>
          </div>

          {/* Desktop Menu */}
          <div className="hidden md:flex items-center space-x-2">
            {isAuthenticated ? (
              <>
                <NavItem to="/dashboard" icon={LayoutDashboard} label="Dashboard" />
                <NavItem to="/upload" icon={UploadCloud} label="Upload" />
                <NavItem to="/analysis" icon={PieChart} label="Analysis" />
                <NavItem to="/metrics" icon={Activity} label="Metrics" />
                
                <div className="h-6 w-px bg-slate-700 mx-4"></div>
                
                <div className="flex items-center space-x-4">
                  <span className="text-sm font-medium text-slate-300">
                    <span className="text-slate-500 mr-1">Hi,</span>
                    {user?.name}
                  </span>
                  <button
                    onClick={logout}
                    className="flex items-center space-x-1 text-sm text-red-400 hover:text-red-300 hover:bg-red-400/10 px-3 py-2 rounded-md transition-colors font-medium"
                  >
                    <LogOut size={16} />
                    <span>Logout</span>
                  </button>
                </div>
              </>
            ) : (
              <>
                <Link to="/login" className="text-slate-300 hover:text-white hover:bg-slate-800 px-3 py-2 rounded-md text-sm font-medium transition-colors">
                  Login
                </Link>
                <Link to="/register" className="ml-2 bg-indigo-600 text-white px-4 py-2 rounded-md text-sm font-medium hover:bg-indigo-500 transition-colors shadow-lg shadow-indigo-900/50">
                  Register
                </Link>
              </>
            )}
          </div>

          {/* Mobile menu button */}
          <div className="flex items-center md:hidden">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="text-slate-400 hover:text-white focus:outline-none p-2 hover:bg-slate-800 rounded-md transition-colors"
            >
              {isOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="md:hidden bg-slate-900 border-b border-slate-800 shadow-xl">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
            {isAuthenticated ? (
              <>
                <NavItem to="/dashboard" icon={LayoutDashboard} label="Dashboard" />
                <NavItem to="/upload" icon={UploadCloud} label="Upload Dataset" />
                <NavItem to="/analysis" icon={PieChart} label="NLP Performance" />
                <NavItem to="/metrics" icon={Activity} label="Model Metrics" />
                <div className="border-t border-slate-800 my-2 pt-2">
                  <div className="px-3 py-2 text-sm text-slate-400">
                    Signed in as <span className="text-white font-medium">{user?.name}</span>
                  </div>
                  <button
                    onClick={() => { logout(); setIsOpen(false); }}
                    className="flex w-full items-center space-x-2 px-3 py-2 text-red-400 font-medium hover:bg-red-400/10 rounded-md"
                  >
                    <LogOut size={18} />
                    <span>Logout</span>
                  </button>
                </div>
              </>
            ) : (
              <>
                <NavItem to="/login" icon={LogIn} label="Login" />
                <Link to="/register" onClick={() => setIsOpen(false)} className="block w-full text-center mt-3 bg-indigo-600 text-white px-4 py-2 rounded-md font-medium hover:bg-indigo-500">
                  Register Now
                </Link>
              </>
            )}
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;