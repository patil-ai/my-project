
import React, { useContext, useState } from 'react';
import { DataContext } from '../App';
import { Dataset } from '../types';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import { UploadCloud, FileText, CheckCircle, AlertCircle, List } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const Upload: React.FC = () => {
  const { uploadDataset, loading } = useContext(DataContext)!;
  const navigate = useNavigate();
  const [file, setFile] = useState<File | null>(null);
  const [csvContent, setCsvContent] = useState<string>('');
  const [headers, setHeaders] = useState<string[]>([]);
  const [selectedColumn, setSelectedColumn] = useState<string>('');
  const [rowCount, setRowCount] = useState(0);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const selected = e.target.files[0];
      if (selected.type !== 'text/csv' && !selected.name.endsWith('.csv')) {
        setError('Please upload a valid CSV file.');
        setFile(null);
        return;
      }
      
      try {
        const text = await selected.text();
        const lines = text.split(/\r?\n/);
        if (lines.length < 2) {
          setError('CSV file is empty or invalid.');
          return;
        }

        // Parse Headers
        const headerLine = lines[0];
        const extractedHeaders = headerLine.split(',').map(h => h.trim().replace(/^"|"$/g, ''));
        
        setFile(selected);
        setCsvContent(text);
        setHeaders(extractedHeaders);
        setRowCount(lines.length);
        setError('');
        setSuccess(false);
        // Default select the first column that looks like text
        const likelyTextCol = extractedHeaders.find(h => h.toLowerCase().includes('text') || h.toLowerCase().includes('review') || h.toLowerCase().includes('content')) || extractedHeaders[0];
        setSelectedColumn(likelyTextCol);

      } catch (err) {
        setError('Error reading file.');
      }
    }
  };

  const handleProcess = async () => {
    if (!file || !selectedColumn) return;
    
    try {
      // Create preview
      const rows = csvContent.split(/\r?\n/).map(r => r.split(','));
      const preview = rows.slice(0, 5);

      const newDataset: Dataset = {
        id: crypto.randomUUID(),
        name: file.name,
        uploadDate: new Date().toISOString(),
        rowCount: rowCount,
        preview,
        content: csvContent,
        textColumn: selectedColumn
      };

      await uploadDataset(newDataset);
      setSuccess(true);
      setTimeout(() => navigate('/dashboard'), 1500);
    } catch (e) {
      setError('Failed to upload/save dataset.');
    }
  };

  return (
    <div className="max-w-3xl mx-auto px-4 py-12">
      <div className="mb-8 text-center">
        <h1 className="text-3xl font-bold text-slate-900">Upload Dataset</h1>
        <p className="text-slate-500 mt-2">Upload your CSV and select the column containing text for analysis.</p>
      </div>

      <Card className="p-8">
        {!file ? (
          <div className="border-2 border-dashed border-slate-300 rounded-lg p-12 text-center hover:border-indigo-500 transition-colors bg-slate-50">
            <input
              type="file"
              id="file-upload"
              className="hidden"
              accept=".csv"
              onChange={handleFileChange}
            />
            <label htmlFor="file-upload" className="cursor-pointer flex flex-col items-center">
               <div className="bg-slate-200 p-4 rounded-full text-slate-500 mb-4">
                 <UploadCloud size={40} />
               </div>
              <span className="text-lg font-medium text-slate-900 block mb-1">
                Click to upload CSV
              </span>
              <span className="text-sm text-slate-500">Max file size: 10MB</span>
            </label>
          </div>
        ) : (
          <div className="space-y-6">
            <div className="flex items-center p-4 bg-indigo-50 rounded-lg border border-indigo-100">
              <div className="bg-indigo-100 p-3 rounded-full text-indigo-600 mr-4">
                <FileText size={24} />
              </div>
              <div className="flex-1">
                <h3 className="font-medium text-slate-900">{file.name}</h3>
                <p className="text-sm text-slate-500">{(file.size / 1024).toFixed(2)} KB • {rowCount} rows</p>
              </div>
              <button onClick={() => { setFile(null); setHeaders([]); }} className="text-sm text-red-600 hover:text-red-700">
                Change
              </button>
            </div>

            <div className="bg-white border border-slate-200 rounded-lg p-6 shadow-sm">
              <label className="block text-sm font-medium text-slate-700 mb-2 flex items-center">
                <List size={16} className="mr-2" />
                Select Text Column for Analysis
              </label>
              <p className="text-xs text-slate-500 mb-4">
                Which column contains the reviews, tweets, or text you want to analyze?
              </p>
              <select
                value={selectedColumn}
                onChange={(e) => setSelectedColumn(e.target.value)}
                className="w-full pl-3 pr-10 py-2.5 text-base border-slate-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md border"
              >
                {headers.map((h, idx) => (
                  <option key={idx} value={h}>{h}</option>
                ))}
              </select>
            </div>

            <div className="flex justify-end pt-4">
              <Button 
                isLoading={loading}
                onClick={handleProcess}
                className="w-full sm:w-auto"
              >
                Save & Process Dataset
              </Button>
            </div>
          </div>
        )}

        {error && (
          <div className="mt-4 p-3 bg-red-50 text-red-600 rounded-lg flex items-center text-sm">
            <AlertCircle size={16} className="mr-2" />
            {error}
          </div>
        )}

        {success && (
          <div className="mt-4 p-3 bg-green-50 text-green-600 rounded-lg flex items-center text-sm">
            <CheckCircle size={16} className="mr-2" />
            Dataset saved successfully! Redirecting...
          </div>
        )}
      </Card>
    </div>
  );
};

export default Upload;
