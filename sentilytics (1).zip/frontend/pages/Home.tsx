import React, { useContext, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { BarChart2, FileText, Zap } from 'lucide-react';
import { AuthContext, DataContext } from '../App';

const Home: React.FC = () => {
  const { login, register } = useContext(AuthContext)!;
  const { loadDemoData } = useContext(DataContext)!;
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);

  const handleLiveDemo = async () => {
    setIsLoading(true);
    const demoEmail = 'demo@sentilytics.com';
    const demoPass = 'demo123';

    try {
      try {
        // Attempt to login directly
        await login(demoEmail, demoPass);
      } catch (loginError) {
        // If login fails, register the demo user first
        await register('Demo User', demoEmail, demoPass);
      }
      
      // Crucial: Load demo data to populate the analysis views immediately
      await loadDemoData();
      
      // Navigate directly to the Analysis page instead of Dashboard
      navigate('/analysis');
      
    } catch (error) {
      console.error("Live Demo failed", error);
      alert("Something went wrong starting the demo. Please try registering manually.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="bg-slate-900 min-h-[calc(100vh-64px)]">
      {/* Hero Section with Beautiful Dark Gradient Background */}
      <div className="relative isolate overflow-hidden">
        {/* Decorative Gradient Blurs */}
        <div
          className="absolute inset-x-0 -top-40 -z-10 transform-gpu overflow-hidden blur-3xl sm:-top-80"
          aria-hidden="true"
        >
          <div
            className="relative left-[calc(50%-11rem)] aspect-[1155/678] w-[36.125rem] -translate-x-1/2 rotate-[30deg] bg-gradient-to-tr from-[#ff80b5] to-[#9089fc] opacity-20 sm:left-[calc(50%-30rem)] sm:w-[72.1875rem]"
            style={{
              clipPath:
                'polygon(74.1% 44.1%, 100% 61.6%, 97.5% 26.9%, 85.5% 0.1%, 80.7% 2%, 72.5% 32.5%, 60.2% 62.4%, 52.4% 68.1%, 47.5% 58.3%, 45.2% 34.5%, 27.5% 76.7%, 0.1% 64.9%, 17.9% 100%, 27.6% 76.8%, 76.1% 97.7%, 74.1% 44.1%)',
            }}
          />
        </div>

        <div className="mx-auto max-w-7xl px-6 pb-24 pt-10 sm:pb-32 lg:flex lg:px-8 lg:py-40">
          <div className="mx-auto max-w-2xl lg:mx-0 lg:max-w-xl lg:flex-shrink-0 lg:pt-8">
            <div className="mt-24 sm:mt-32 lg:mt-16">
              <span className="rounded-full bg-indigo-500/10 px-3 py-1 text-sm font-semibold leading-6 text-indigo-400 ring-1 ring-inset ring-indigo-500/20">
                Latest Release v2.0
              </span>
            </div>
            <h1 className="mt-10 text-4xl font-bold tracking-tight text-white sm:text-6xl">
              Unlock insights with <span className="text-indigo-400">AI Sentiment Analysis</span>
            </h1>
            <p className="mt-6 text-lg leading-8 text-gray-300">
              Sentilytics processes your raw text datasets using advanced NLP models to reveal emotional trends, key topics, and predictive metrics in seconds.
            </p>
            <div className="mt-10 flex items-center gap-x-6">
              <Link
                to="/register"
                className="rounded-md bg-indigo-500 px-3.5 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-indigo-400 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-400 transition-all duration-200"
              >
                Get Started
              </Link>
              <button
                onClick={handleLiveDemo}
                disabled={isLoading}
                className="group flex items-center gap-2 text-sm font-semibold leading-6 text-white hover:text-indigo-300 transition-colors"
              >
                {isLoading ? 'Loading Demo...' : 'Live Demo'} 
                {!isLoading && <span aria-hidden="true" className="group-hover:translate-x-1 transition-transform">→</span>}
              </button>
            </div>
          </div>
          
          {/* Abstract Dashboard Visual - Pure CSS Representation */}
          <div className="mx-auto mt-16 flex max-w-2xl sm:mt-24 lg:ml-10 lg:mt-0 lg:mr-0 lg:max-w-none lg:flex-none xl:ml-32">
            <div className="max-w-3xl flex-none sm:max-w-5xl lg:max-w-none">
              <div className="-m-2 rounded-xl bg-gray-900/5 p-2 ring-1 ring-inset ring-gray-900/10 lg:-m-4 lg:rounded-2xl lg:p-4">
                <div className="rounded-md bg-slate-800/80 shadow-2xl ring-1 ring-white/10 p-6 backdrop-blur-md border border-white/10 w-[300px] sm:w-[500px]">
                   {/* Fake UI Elements */}
                   <div className="flex space-x-2 mb-4">
                     <div className="h-3 w-3 rounded-full bg-red-500"></div>
                     <div className="h-3 w-3 rounded-full bg-yellow-500"></div>
                     <div className="h-3 w-3 rounded-full bg-green-500"></div>
                   </div>
                   <div className="space-y-3">
                     <div className="h-4 bg-slate-700 rounded w-3/4 animate-pulse"></div>
                     <div className="h-4 bg-slate-700 rounded w-1/2 animate-pulse"></div>
                     <div className="h-32 bg-indigo-900/30 rounded mt-4 border border-indigo-500/30 flex items-center justify-center">
                        <BarChart2 className="text-indigo-400 h-12 w-12 opacity-50" />
                     </div>
                   </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Gradient Blob */}
        <div
          className="absolute inset-x-0 top-[calc(100%-13rem)] -z-10 transform-gpu overflow-hidden blur-3xl sm:top-[calc(100%-30rem)]"
          aria-hidden="true"
        >
          <div
            className="relative left-[calc(50%+3rem)] aspect-[1155/678] w-[36.125rem] -translate-x-1/2 bg-gradient-to-tr from-[#ff80b5] to-[#9089fc] opacity-20 sm:left-[calc(50%+36rem)] sm:w-[72.1875rem]"
            style={{
              clipPath:
                'polygon(74.1% 44.1%, 100% 61.6%, 97.5% 26.9%, 85.5% 0.1%, 80.7% 2%, 72.5% 32.5%, 60.2% 62.4%, 52.4% 68.1%, 47.5% 58.3%, 45.2% 34.5%, 27.5% 76.7%, 0.1% 64.9%, 17.9% 100%, 27.6% 76.8%, 76.1% 97.7%, 74.1% 44.1%)',
            }}
          />
        </div>
      </div>

      {/* Feature Section - Updated to Dark Theme */}
      <div className="py-24 border-t border-slate-800 sm:py-32">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="mx-auto max-w-2xl lg:text-center">
            <h2 className="text-base font-semibold leading-7 text-indigo-400">Deploy faster</h2>
            <p className="mt-2 text-3xl font-bold tracking-tight text-white sm:text-4xl">
              Everything you need to understand your data
            </p>
            <p className="mt-6 text-lg leading-8 text-slate-400">
              Stop guessing. Start knowing. Sentilytics provides the comprehensive toolset needed to turn unstructured text into actionable business intelligence.
            </p>
          </div>
          <div className="mx-auto mt-16 max-w-2xl sm:mt-20 lg:mt-24 lg:max-w-4xl">
            <dl className="grid max-w-xl grid-cols-1 gap-x-8 gap-y-10 lg:max-w-none lg:grid-cols-3 lg:gap-y-16">
              <div className="relative pl-16">
                <dt className="text-base font-semibold leading-7 text-white">
                  <div className="absolute left-0 top-0 flex h-10 w-10 items-center justify-center rounded-lg bg-white/5 ring-1 ring-white/10">
                    <FileText className="h-6 w-6 text-indigo-400" aria-hidden="true" />
                  </div>
                  Dataset Processing
                </dt>
                <dd className="mt-2 text-base leading-7 text-slate-400">
                  Upload CSV files securely. We parse, validate, and clean your text data automatically.
                </dd>
              </div>
              <div className="relative pl-16">
                <dt className="text-base font-semibold leading-7 text-white">
                  <div className="absolute left-0 top-0 flex h-10 w-10 items-center justify-center rounded-lg bg-white/5 ring-1 ring-white/10">
                    <BarChart2 className="h-6 w-6 text-indigo-400" aria-hidden="true" />
                  </div>
                  Visual Analytics
                </dt>
                <dd className="mt-2 text-base leading-7 text-slate-400">
                  Interactive Word Clouds, Sentiment Distribution Charts, and Trend Lines.
                </dd>
              </div>
              <div className="relative pl-16">
                <dt className="text-base font-semibold leading-7 text-white">
                  <div className="absolute left-0 top-0 flex h-10 w-10 items-center justify-center rounded-lg bg-white/5 ring-1 ring-white/10">
                    <Zap className="h-6 w-6 text-indigo-400" aria-hidden="true" />
                  </div>
                  ML Metrics
                </dt>
                <dd className="mt-2 text-base leading-7 text-slate-400">
                  Simulate Logistic Regression and Decision Tree performance (F1, Precision, Recall).
                </dd>
              </div>
            </dl>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Home;