import React, { useContext } from 'react';
import { DataContext } from '../App';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from 'recharts';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import { Loader, TrendingUp, AlertTriangle, Download, Cloud } from 'lucide-react';

const COLORS = ['#10B981', '#F59E0B', '#EF4444']; // Green, Yellow, Red

const Analysis: React.FC = () => {
  const { nlpResults, modelMetrics, loading } = useContext(DataContext)!;

  const handleDownloadReport = () => {
    if (!nlpResults) return;

    const reportData = {
      timestamp: new Date().toISOString(),
      analysis: nlpResults,
      mlMetrics: modelMetrics
    };

    const blob = new Blob([JSON.stringify(reportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `sentilytics_report_${nlpResults.datasetId}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  if (loading) {
    return (
      <div className="min-h-[60vh] flex flex-col items-center justify-center text-slate-500">
        <Loader className="animate-spin h-12 w-12 text-indigo-600 mb-4" />
        <p className="text-lg font-medium">Analyzing Sentiment with Gemini AI...</p>
        <p className="text-sm">Generating word clouds and classification metrics...</p>
      </div>
    );
  }

  if (!nlpResults) {
    return (
      <div className="text-center py-20">
        <h2 className="text-2xl font-bold text-slate-700">No Analysis Available</h2>
        <p className="text-slate-500 mt-2">Go to Dashboard and run analysis on a dataset first.</p>
      </div>
    );
  }

  const chartData = [
    { name: 'Positive', value: nlpResults.stats.positive },
    { name: 'Neutral', value: nlpResults.stats.neutral },
    { name: 'Negative', value: nlpResults.stats.negative },
  ];

  // Helper to filter words
  const getWordsBySentiment = (sentiment: 'positive' | 'negative' | 'neutral') => {
    return nlpResults.wordCloud.filter(w => w.sentiment === sentiment);
  };

  const WordCloudSection = ({ title, sentiment, colorClass, items }: any) => (
    <div className="flex flex-col items-center">
      <h3 className={`text-lg font-bold mb-4 ${colorClass}`}>{title}</h3>
      <div className="relative flex items-center justify-center w-full aspect-square max-w-sm bg-slate-50 rounded-full border border-slate-200 shadow-inner p-8 overflow-hidden">
        <div className="flex flex-wrap justify-center items-center content-center gap-x-3 gap-y-1">
          {items.length > 0 ? (
            items.map((item: any, idx: number) => {
              // Standard word cloud scaling: larger font for higher value
              // Base size 0.75rem, add dynamic amount based on value (capped)
              const fontSize = `${0.75 + Math.min(2.5, item.value / 8)}rem`;
              const opacity = 0.6 + Math.min(0.4, item.value / 40);
              
              // Random slight rotation for natural look
              const rotate = idx % 2 === 0 ? '0deg' : idx % 5 === 0 ? '-5deg' : idx % 7 === 0 ? '5deg' : '0deg';

              return (
                <span
                  key={idx}
                  className={`font-bold leading-none cursor-default hover:scale-110 transition-transform duration-200 ${colorClass}`}
                  style={{ 
                    fontSize, 
                    opacity,
                    transform: `rotate(${rotate})` 
                  }}
                  title={`Count: ${item.value}`}
                >
                  {item.text}
                </span>
              );
            })
          ) : (
            <span className="text-sm text-slate-400 italic">No words found.</span>
          )}
        </div>
      </div>
    </div>
  );

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold text-slate-900">NLP Analysis Results</h1>
        <Button onClick={handleDownloadReport} variant="outline" className="flex items-center gap-2">
          <Download size={18} /> Download Report
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-12">
        {/* Pie Chart */}
        <Card title="Sentiment Distribution" className="h-96">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={chartData}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={100}
                fill="#8884d8"
                paddingAngle={5}
                dataKey="value"
              >
                {chartData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
              <Legend verticalAlign="bottom" height={36}/>
            </PieChart>
          </ResponsiveContainer>
        </Card>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 gap-4">
           <Card className="flex items-center justify-between border-l-4 border-l-green-500">
              <div>
                <p className="text-sm text-slate-500 font-medium">Positive Sentiments</p>
                <h3 className="text-3xl font-bold text-slate-800">{nlpResults.stats.positive}</h3>
              </div>
              <div className="h-12 w-12 rounded-full bg-green-100 flex items-center justify-center text-green-600">
                <TrendingUp size={24} />
              </div>
           </Card>
           <Card className="flex items-center justify-between border-l-4 border-l-yellow-500">
              <div>
                <p className="text-sm text-slate-500 font-medium">Neutral Sentiments</p>
                <h3 className="text-3xl font-bold text-slate-800">{nlpResults.stats.neutral}</h3>
              </div>
              <div className="h-12 w-12 rounded-full bg-yellow-100 flex items-center justify-center text-yellow-600">
                 <div className="h-2 w-6 bg-yellow-500 rounded-full"></div>
              </div>
           </Card>
           <Card className="flex items-center justify-between border-l-4 border-l-red-500">
              <div>
                <p className="text-sm text-slate-500 font-medium">Negative Sentiments</p>
                <h3 className="text-3xl font-bold text-slate-800">{nlpResults.stats.negative}</h3>
              </div>
              <div className="h-12 w-12 rounded-full bg-red-100 flex items-center justify-center text-red-600">
                <AlertTriangle size={24} />
              </div>
           </Card>
        </div>
      </div>

      {/* Word Cloud Section */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-8 mb-12">
        <h2 className="text-2xl font-bold text-slate-900 mb-8 flex items-center gap-2 justify-center">
          <Cloud className="text-indigo-600" /> Sentiment Word Clusters
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 justify-items-center">
          <WordCloudSection 
            title="Positive" 
            sentiment="positive" 
            colorClass="text-emerald-600"
            items={getWordsBySentiment('positive')} 
          />
          <WordCloudSection 
            title="Negative" 
            sentiment="negative" 
            colorClass="text-rose-600"
            items={getWordsBySentiment('negative')} 
          />
          <WordCloudSection 
            title="Neutral" 
            sentiment="neutral" 
            colorClass="text-slate-500"
            items={getWordsBySentiment('neutral')} 
          />
        </div>
      </div>

      {/* Classification Scores Section */}
      <h2 className="text-2xl font-bold text-slate-900 mb-4">Classification Model Scores</h2>
      {modelMetrics.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {modelMetrics.map((model) => (
             <Card key={model.modelName} title={model.modelName} className="border-t-4 border-t-indigo-500">
                <div className="grid grid-cols-2 gap-4">
                  <div className="flex flex-col p-3 bg-slate-50 rounded-lg">
                    <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Accuracy</span>
                    <span className="text-2xl font-bold text-slate-800">{(model.accuracy * 100).toFixed(1)}%</span>
                  </div>
                  <div className="flex flex-col p-3 bg-indigo-50 rounded-lg">
                    <span className="text-xs font-semibold text-indigo-500 uppercase tracking-wider">F1 Score</span>
                    <span className="text-2xl font-bold text-indigo-700">{(model.f1Score * 100).toFixed(1)}%</span>
                  </div>
                  <div className="flex flex-col p-3 bg-slate-50 rounded-lg">
                    <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Precision</span>
                    <span className="text-lg font-semibold text-slate-700">{(model.precision * 100).toFixed(1)}%</span>
                  </div>
                  <div className="flex flex-col p-3 bg-slate-50 rounded-lg">
                    <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Recall</span>
                    <span className="text-lg font-semibold text-slate-700">{(model.recall * 100).toFixed(1)}%</span>
                  </div>
                </div>
             </Card>
          ))}
        </div>
      ) : (
        <div className="p-8 bg-slate-100 rounded-xl text-center text-slate-500">
          No Classification Scores generated yet.
        </div>
      )}
    </div>
  );
};

export default Analysis;