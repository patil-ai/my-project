import React, { useState, useEffect, createContext, useContext } from 'react';
import { HashRouter, Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { User, AuthState, Dataset, NLPResults, ModelMetric } from './types';
import { api } from '../backend/api';
import { GeminiService } from './services/gemini';
import Navbar from './components/Navbar';
import Home from './pages/Home';
import Login from './pages/Login';
import Register from './pages/Register';
import Dashboard from './pages/Dashboard';
import Upload from './pages/Upload';
import Analysis from './pages/Analysis';
import MLMetrics from './pages/MLMetrics';

// --- Auth Context ---
interface AuthContextType extends AuthState {
  login: (email: string, password: string) => Promise<void>;
  register: (name: string, email: string, password: string) => Promise<void>;
  logout: () => void;
}

export const AuthContext = createContext<AuthContextType | undefined>(undefined);

// --- Data Context ---
interface DataContextType {
  datasets: Dataset[];
  nlpResults: NLPResults | null;
  modelMetrics: ModelMetric[];
  loading: boolean;
  uploadDataset: (dataset: Dataset) => Promise<void>;
  runAnalysis: (id: string) => Promise<void>;
  loadDashboardData: () => Promise<void>;
  loadDemoData: () => Promise<void>;
}

export const DataContext = createContext<DataContextType | undefined>(undefined);

// --- Protected Route Helper ---
const ProtectedRoute = ({ children }: { children?: React.ReactNode }) => {
  const { isAuthenticated } = useContext(AuthContext)!;
  const location = useLocation();

  if (!isAuthenticated) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }
  return <>{children}</>;
};

const App: React.FC = () => {
  // Auth State
  const [auth, setAuth] = useState<AuthState>({
    user: null,
    token: localStorage.getItem('token'),
    isAuthenticated: !!localStorage.getItem('token'),
  });

  // Data State
  const [datasets, setDatasets] = useState<Dataset[]>([]);
  const [nlpResults, setNlpResults] = useState<NLPResults | null>(null);
  const [modelMetrics, setModelMetrics] = useState<ModelMetric[]>([]);
  const [loading, setLoading] = useState(false);

  // Initialize Services
  const gemini = new GeminiService();

  useEffect(() => {
    // Check session on load
    const checkSession = async () => {
      if (auth.token) {
        const user = await api.getUserProfile(auth.token);
        if (user) {
          setAuth({ user, token: auth.token, isAuthenticated: true });
        } else {
          logout();
        }
      }
    };
    checkSession();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const login = async (email: string, pass: string) => {
    const res = await api.login(email, pass);
    if (res.token && res.user) {
      localStorage.setItem('token', res.token);
      setAuth({ user: res.user, token: res.token, isAuthenticated: true });
    } else {
      throw new Error('Invalid credentials');
    }
  };

  const register = async (name: string, email: string, pass: string) => {
    await api.register(name, email, pass);
    await login(email, pass);
  };

  const logout = () => {
    localStorage.removeItem('token');
    setAuth({ user: null, token: null, isAuthenticated: false });
    setDatasets([]);
    setNlpResults(null);
    setModelMetrics([]);
  };

  const uploadDataset = async (dataset: Dataset) => {
    setLoading(true);
    try {
      await api.uploadDataset(dataset);
      setDatasets(prev => [...prev, dataset]);
    } catch (e) {
      console.error(e);
      throw e;
    } finally {
      setLoading(false);
    }
  };

  const runAnalysis = async (datasetId: string) => {
    setLoading(true);
    try {
      const dataset = await api.getDataset(datasetId);
      if (!dataset) throw new Error("Dataset not found");

      // Extract specific column data for better analysis
      let textData = dataset.content;
      if (dataset.textColumn) {
        // Robust CSV splitting handling quoted commas
        const lines = dataset.content.split(/\r?\n/);
        const headers = lines[0].split(',').map(h => h.trim().replace(/^"|"$/g, ''));
        const colIndex = headers.indexOf(dataset.textColumn);
        
        if (colIndex !== -1) {
          // Simple parser for logic sake, for production use a library
          const columnValues = lines.slice(1).map(line => {
             // Basic regex to handle CSV split with quotes
             const matches = line.match(/(".*?"|[^",\s]+)(?=\s*,|\s*$)/g);
             // Fallback to simple split if regex fails or simple structure
             const parts = matches || line.split(',');
             return parts[colIndex] ? parts[colIndex].replace(/^"|"$/g, '') : '';
          }).filter(val => val.length > 5); // Filter empty or too short rows
          
          textData = columnValues.join('\n');
        }
      }

      // 1. NLP Analysis via Gemini with specific column data
      const results = await gemini.analyzeSentiment(textData);
      const resultsWithId = { ...results, datasetId };
      setNlpResults(resultsWithId);

      // 2. ML Metrics via Gemini
      const metrics = await gemini.generateMLMetrics(textData);
      setModelMetrics(metrics);

    } catch (error) {
      console.error("Analysis failed:", error);
      alert("Analysis failed. Please check your API Key and try again.");
    } finally {
      setLoading(false);
    }
  };

  const loadDashboardData = async () => {
    const d = await api.getAllDatasets();
    setDatasets(d);
  };

  // Pre-load data for Live Demo to show instant value
  const loadDemoData = async () => {
    setLoading(true);
    // Simulate loading delay for realism
    await new Promise(r => setTimeout(r, 800));

    // 1. Create a dummy dataset in state (optional to save to DB, but state is enough for demo session)
    const demoDataset: Dataset = {
      id: 'demo-dataset-1',
      name: 'Tech_Product_Reviews_Sample.csv',
      uploadDate: new Date().toISOString(),
      rowCount: 1250,
      preview: [
        ['ID', 'Review', 'Sentiment'],
        ['1', 'Absolutely love this phone, battery life is amazing.', 'Positive'],
        ['2', 'The screen cracked after one day. Terrible quality.', 'Negative'],
        ['3', 'It is okay, does the job but nothing special.', 'Neutral'],
        ['4', 'Customer support was very helpful in solving my issue.', 'Positive']
      ],
      content: 'ID,Review,Sentiment\n...', 
      textColumn: 'Review'
    };
    setDatasets([demoDataset]);

    // 2. Set detailed Demo NLP Results
    setNlpResults({
      datasetId: 'demo-dataset-1',
      summary: "The analysis of the Tech Product Reviews dataset reveals a predominantly positive sentiment (62%), driven by high satisfaction with 'battery life', 'performance', and 'customer support'. However, there is a notable cluster of negative feedback (15%) focusing on 'screen quality' and 'shipping delays'. Neutral reviews often discuss 'price' and standard 'features' without strong emotion. Overall, the product is well-received but quality control on hardware needs attention.",
      stats: {
        positive: 775,
        neutral: 287,
        negative: 188,
        total: 1250
      },
      wordCloud: [
        // Positive
        { text: 'Excellent', value: 95, sentiment: 'positive' },
        { text: 'Amazing', value: 88, sentiment: 'positive' },
        { text: 'Fast', value: 82, sentiment: 'positive' },
        { text: 'Love', value: 76, sentiment: 'positive' },
        { text: 'Reliable', value: 70, sentiment: 'positive' },
        { text: 'Great', value: 65, sentiment: 'positive' },
        { text: 'Smooth', value: 60, sentiment: 'positive' },
        { text: 'Helpful', value: 55, sentiment: 'positive' },
        { text: 'Best', value: 50, sentiment: 'positive' },
        { text: 'Quality', value: 45, sentiment: 'positive' },
        
        // Negative
        { text: 'Broken', value: 45, sentiment: 'negative' },
        { text: 'Slow', value: 42, sentiment: 'negative' },
        { text: 'Worst', value: 40, sentiment: 'negative' },
        { text: 'Expensive', value: 38, sentiment: 'negative' },
        { text: 'Buggy', value: 35, sentiment: 'negative' },
        { text: 'Glitch', value: 30, sentiment: 'negative' },
        { text: 'Terrible', value: 28, sentiment: 'negative' },
        { text: 'Crash', value: 25, sentiment: 'negative' },
        { text: 'Poor', value: 22, sentiment: 'negative' },
        
        // Neutral
        { text: 'Price', value: 60, sentiment: 'neutral' },
        { text: 'Standard', value: 55, sentiment: 'neutral' },
        { text: 'Average', value: 50, sentiment: 'neutral' },
        { text: 'Okay', value: 45, sentiment: 'neutral' },
        { text: 'Design', value: 40, sentiment: 'neutral' },
        { text: 'Feature', value: 35, sentiment: 'neutral' },
        { text: 'Normal', value: 30, sentiment: 'neutral' }
      ]
    });

    // 3. Set detailed Demo ML Metrics
    setModelMetrics([
      {
        modelName: "Logistic Regression",
        accuracy: 0.885,
        precision: 0.862,
        recall: 0.891,
        f1Score: 0.876,
        confusionMatrix: { tp: 420, tn: 465, fp: 65, fn: 50 }
      },
      {
        modelName: "Decision Tree",
        accuracy: 0.842,
        precision: 0.815,
        recall: 0.820,
        f1Score: 0.817,
        confusionMatrix: { tp: 390, tn: 452, fp: 78, fn: 80 }
      }
    ]);
    
    setLoading(false);
  };

  return (
    <AuthContext.Provider value={{ ...auth, login, register, logout }}>
      <DataContext.Provider value={{ datasets, nlpResults, modelMetrics, loading, uploadDataset, runAnalysis, loadDashboardData, loadDemoData }}>
        <HashRouter>
          <div className="min-h-screen bg-slate-50 flex flex-col font-sans text-slate-900">
            <Navbar />
            <div className="flex-grow">
              <Routes>
                <Route path="/" element={<Home />} />
                <Route path="/login" element={<Login />} />
                <Route path="/register" element={<Register />} />
                
                <Route path="/dashboard" element={
                  <ProtectedRoute><Dashboard /></ProtectedRoute>
                } />
                <Route path="/upload" element={
                  <ProtectedRoute><Upload /></ProtectedRoute>
                } />
                <Route path="/analysis" element={
                  <ProtectedRoute><Analysis /></ProtectedRoute>
                } />
                <Route path="/metrics" element={
                  <ProtectedRoute><MLMetrics /></ProtectedRoute>
                } />
              </Routes>
            </div>
            <footer className="bg-slate-900 text-slate-400 py-6 text-center text-sm">
              &copy; {new Date().getFullYear()} Sentilytics. Powered by Gemini API & React.
            </footer>
          </div>
        </HashRouter>
      </DataContext.Provider>
    </AuthContext.Provider>
  );
};

export default App;