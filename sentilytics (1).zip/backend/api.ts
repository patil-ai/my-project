
import { Dataset, User } from '../frontend/types';
import { ServerDB } from './database';

// Simulates a Node.js/Express Backend API Layer
class BackendAPI {
  private db: ServerDB;

  constructor() {
    this.db = new ServerDB();
  }

  private delay(ms: number) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  // Auth Routes
  async register(name: string, email: string, pass: string): Promise<User> {
    await this.delay(500);
    
    const existingUser = await this.db.findUserByEmail(email);
    if (existingUser) {
      throw new Error('User already exists');
    }

    const newUser = { 
      id: crypto.randomUUID(), 
      name, 
      email, 
      password: pass // In a real app, hash this!
    };
    
    await this.db.add('users', newUser);
    
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const { password, ...userProfile } = newUser;
    return userProfile;
  }

  async login(email: string, pass: string): Promise<{ user: User | null, token: string | null }> {
    await this.delay(600);
    const user = await this.db.findUserByEmail(email);

    if (!user || user.password !== pass) {
      return { user: null, token: null };
    }

    const token = `jwt-simulation-${user.id}-${Date.now()}`;
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const { password, ...userProfile } = user;
    return { user: userProfile, token };
  }

  async getUserProfile(token: string): Promise<User | null> {
    await this.delay(200);
    if (!token || !token.startsWith('jwt-simulation-')) return null;
    
    const userId = token.split('-')[2];
    const user = await this.db.get<any>('users', userId);
    
    if (!user) return null;
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const { password, ...userProfile } = user;
    return userProfile;
  }

  // Dataset Routes
  async uploadDataset(dataset: Dataset): Promise<void> {
    await this.delay(800);
    // IndexedDB handles large files much better than localStorage
    await this.db.add('datasets', dataset);
  }

  async getAllDatasets(): Promise<Dataset[]> {
    await this.delay(400);
    return await this.db.getAll<Dataset>('datasets');
  }

  async getDataset(id: string): Promise<Dataset | null> {
    const dataset = await this.db.get<Dataset>('datasets', id);
    return dataset || null;
  }
}

export const api = new BackendAPI();
