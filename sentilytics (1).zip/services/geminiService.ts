import { GoogleGenAI, Type } from "@google/genai";
import { NLPResults, ModelMetric } from '../types';

export class GeminiService {
  private ai: GoogleGenAI;

  constructor() {
    this.ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
  }

  async analyzeSentiment(csvData: string): Promise<Omit<NLPResults, 'datasetId'>> {
    // Truncate CSV to avoid token limits for this demo, taking a sample
    const sampleData = csvData.slice(0, 15000); 

    const prompt = `
      Analyze the sentiment of the following CSV text data. 
      The CSV likely contains a text column. Identify it and perform sentiment analysis.
      
      Return a JSON object with:
      1. 'stats': { positive, negative, neutral, total } (counts based on your analysis of the sample).
      2. 'summary': A short paragraph summarizing the key themes and sentiment drivers.
      3. 'wordCloud': An array of objects { text: string, value: number, sentiment: 'positive'|'negative'|'neutral' }. 
         Provide top 30 most frequent significant words (exclude stop words).
    `;

    try {
      const response = await this.ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt + "\n\nDATA SAMPLE:\n" + sampleData,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              stats: {
                type: Type.OBJECT,
                properties: {
                  positive: { type: Type.NUMBER },
                  negative: { type: Type.NUMBER },
                  neutral: { type: Type.NUMBER },
                  total: { type: Type.NUMBER },
                }
              },
              summary: { type: Type.STRING },
              wordCloud: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    text: { type: Type.STRING },
                    value: { type: Type.NUMBER },
                    sentiment: { type: Type.STRING, enum: ['positive', 'negative', 'neutral'] }
                  }
                }
              }
            }
          }
        }
      });

      if (response.text) {
        return JSON.parse(response.text);
      }
      throw new Error("No response text");
    } catch (error) {
      console.error("Gemini Analysis Error:", error);
      throw error;
    }
  }

  async generateMLMetrics(csvData: string): Promise<ModelMetric[]> {
    const sampleData = csvData.slice(0, 15000);

    const prompt = `
      Act as a Machine Learning Engineer.
      Based on the text data patterns in the provided CSV sample, SIMULATE the training and evaluation of two models:
      1. Logistic Regression
      2. Decision Tree

      Estimate their performance metrics for a sentiment classification task on this specific data.
      Return a JSON array where each object contains:
      - modelName
      - accuracy (0-1)
      - precision (0-1)
      - recall (0-1)
      - f1Score (0-1)
      - confusionMatrix: { tp, tn, fp, fn } (integers representing a test set size of 1000)
    `;

    try {
      const response = await this.ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt + "\n\nDATA SAMPLE:\n" + sampleData,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                modelName: { type: Type.STRING },
                accuracy: { type: Type.NUMBER },
                precision: { type: Type.NUMBER },
                recall: { type: Type.NUMBER },
                f1Score: { type: Type.NUMBER },
                confusionMatrix: {
                  type: Type.OBJECT,
                  properties: {
                    tp: { type: Type.NUMBER },
                    tn: { type: Type.NUMBER },
                    fp: { type: Type.NUMBER },
                    fn: { type: Type.NUMBER },
                  }
                }
              }
            }
          }
        }
      });

      if (response.text) {
        return JSON.parse(response.text);
      }
      throw new Error("No metrics generated");
    } catch (error) {
      console.error("Gemini ML Metrics Error:", error);
      throw error;
    }
  }
}