import { Dataset, User } from '../types';

// This service simulates the Backend (Node.js + MySQL)
// We use localStorage as a "Server.db" file

const DB_KEYS = {
  USERS: 'sentilytics_users',
  DATASETS: 'sentilytics_datasets',
};

export class DatabaseService {
  private delay(ms: number) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  // --- Auth Controller Simulation ---

  async register(name: string, email: string, pass: string): Promise<User> {
    await this.delay(500); // Simulate network latency
    const users = JSON.parse(localStorage.getItem(DB_KEYS.USERS) || '[]');
    
    if (users.find((u: any) => u.email === email)) {
      throw new Error('User already exists');
    }

    // Hash password would happen here in real backend
    const newUser = { id: crypto.randomUUID(), name, email, password: pass }; // Storing plain text only for demo!
    users.push(newUser);
    localStorage.setItem(DB_KEYS.USERS, JSON.stringify(users));
    
    const { password, ...userProfile } = newUser;
    return userProfile;
  }

  async login(email: string, pass: string): Promise<{ user: User | null, token: string | null }> {
    await this.delay(600);
    const users = JSON.parse(localStorage.getItem(DB_KEYS.USERS) || '[]');
    const user = users.find((u: any) => u.email === email && u.password === pass);

    if (!user) return { user: null, token: null };

    // Create a fake JWT
    const token = `jwt-simulation-${user.id}-${Date.now()}`;
    const { password, ...userProfile } = user;
    return { user: userProfile, token };
  }

  async getUserProfile(token: string): Promise<User | null> {
    await this.delay(200);
    if (!token.startsWith('jwt-simulation-')) return null;
    
    const userId = token.split('-')[2];
    const users = JSON.parse(localStorage.getItem(DB_KEYS.USERS) || '[]');
    const user = users.find((u: any) => u.id === userId);
    
    if (!user) return null;
    const { password, ...userProfile } = user;
    return userProfile;
  }

  // --- Dataset Controller Simulation ---

  async saveDataset(dataset: Dataset): Promise<void> {
    await this.delay(800);
    const datasets = JSON.parse(localStorage.getItem(DB_KEYS.DATASETS) || '[]');
    datasets.push(dataset);
    localStorage.setItem(DB_KEYS.DATASETS, JSON.stringify(datasets));
  }

  async getAllDatasets(): Promise<Dataset[]> {
    await this.delay(400);
    return JSON.parse(localStorage.getItem(DB_KEYS.DATASETS) || '[]');
  }

  async getDataset(id: string): Promise<Dataset | null> {
    const datasets = await this.getAllDatasets();
    return datasets.find(d => d.id === id) || null;
  }
}