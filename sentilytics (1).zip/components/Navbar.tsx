import React, { useContext, useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { AuthContext } from '../App';
import { Menu, X, BrainCircuit, LayoutDashboard, UploadCloud, PieChart, Activity, LogOut, LogIn } from 'lucide-react';

const Navbar: React.FC = () => {
  const { isAuthenticated, user, logout } = useContext(AuthContext)!;
  const [isOpen, setIsOpen] = useState(false);
  const location = useLocation();

  const isActive = (path: string) => location.pathname === path ? 'text-indigo-600 bg-indigo-50' : 'text-slate-600 hover:text-indigo-600 hover:bg-slate-50';

  const NavItem = ({ to, icon: Icon, label }: any) => (
    <Link
      to={to}
      onClick={() => setIsOpen(false)}
      className={`flex items-center space-x-2 px-3 py-2 rounded-md text-sm font-medium transition-colors ${isActive(to)}`}
    >
      <Icon size={18} />
      <span>{label}</span>
    </Link>
  );

  return (
    <nav className="bg-white border-b border-slate-200 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <Link to="/" className="flex items-center space-x-2">
              <div className="bg-indigo-600 p-2 rounded-lg">
                <BrainCircuit className="text-white h-6 w-6" />
              </div>
              <span className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-indigo-600 to-violet-600">
                Sentilytics
              </span>
            </Link>
          </div>

          {/* Desktop Menu */}
          <div className="hidden md:flex items-center space-x-4">
            {isAuthenticated ? (
              <>
                <NavItem to="/dashboard" icon={LayoutDashboard} label="Dashboard" />
                <NavItem to="/upload" icon={UploadCloud} label="Upload Dataset" />
                <NavItem to="/analysis" icon={PieChart} label="NLP Performance" />
                <NavItem to="/metrics" icon={Activity} label="Model Metrics" />
                <div className="h-6 w-px bg-slate-200 mx-2"></div>
                <div className="flex items-center space-x-4">
                  <span className="text-sm font-medium text-slate-700">Hi, {user?.name}</span>
                  <button
                    onClick={logout}
                    className="flex items-center space-x-1 text-sm text-red-600 hover:text-red-700 font-medium"
                  >
                    <LogOut size={16} />
                    <span>Logout</span>
                  </button>
                </div>
              </>
            ) : (
              <>
                <Link to="/login" className="text-slate-600 hover:text-indigo-600 px-3 py-2 text-sm font-medium">Login</Link>
                <Link to="/register" className="bg-indigo-600 text-white px-4 py-2 rounded-md text-sm font-medium hover:bg-indigo-700 transition-colors shadow-sm">
                  Register
                </Link>
              </>
            )}
          </div>

          {/* Mobile menu button */}
          <div className="flex items-center md:hidden">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="text-slate-500 hover:text-slate-700 focus:outline-none"
            >
              {isOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="md:hidden bg-white border-b border-slate-200">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
            {isAuthenticated ? (
              <>
                <NavItem to="/dashboard" icon={LayoutDashboard} label="Dashboard" />
                <NavItem to="/upload" icon={UploadCloud} label="Upload" />
                <NavItem to="/analysis" icon={PieChart} label="Analysis" />
                <NavItem to="/metrics" icon={Activity} label="Metrics" />
                <button
                  onClick={() => { logout(); setIsOpen(false); }}
                  className="flex w-full items-center space-x-2 px-3 py-2 text-red-600 font-medium"
                >
                  <LogOut size={18} />
                  <span>Logout</span>
                </button>
              </>
            ) : (
              <>
                <NavItem to="/login" icon={LogIn} label="Login" />
                <Link to="/register" onClick={() => setIsOpen(false)} className="block w-full text-center mt-2 bg-indigo-600 text-white px-4 py-2 rounded-md">
                  Register Now
                </Link>
              </>
            )}
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;